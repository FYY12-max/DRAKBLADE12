package com.darkblade.bug

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var logBox: LinearLayout
    private var running = false

    private val bg = Color.rgb(10, 10, 12)
    private val panel = Color.rgb(25, 25, 29)
    private val red = Color.rgb(255, 48, 48)
    private val white = Color.rgb(245, 245, 245)
    private val muted = Color.rgb(170, 170, 178)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        addLog("Sistem siap. Mode simulasi lokal aktif.")
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 16)
        }

        val logo = TextView(this).apply {
            text = "☠"
            textSize = 48f
            gravity = Gravity.CENTER
            setTextColor(red)
        }
        content.addView(logo, matchWrap())

        val title = TextView(this).apply {
            text = "DARKBLADE BUG"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(white)
        }
        content.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "LAB SIMULASI • ANDROID"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(red)
            setPadding(0, 6, 0, 22)
        }
        content.addView(subtitle, matchWrap())

        val status = TextView(this).apply {
            text = "STATUS: SIAP"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(red)
            setPadding(14, 14, 14, 14)
            setBackgroundColor(panel)
        }
        content.addView(status, matchWrap())

        fun addAction(label: String, action: () -> Unit) {
            val button = Button(this).apply {
                text = label
                textSize = 14f
                setTextColor(white)
                setBackgroundColor(Color.rgb(125, 20, 28))
                setOnClickListener { action() }
            }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.topMargin = 10
            content.addView(button, params)
        }

        addAction("Jalankan simulasi crash") {
            addLog("SIMULASI: crash terdeteksi (contoh lokal; aplikasi tetap berjalan).")
        }
        addAction("Uji input tidak valid") {
            val sample = "###INVALID###"
            val valid = sample.matches(Regex("[A-Za-z0-9_]{1,24}"))
            addLog("UJI INPUT: valid=$valid; input contoh ditolak oleh validator.")
        }
        addAction("Simulasikan respons lambat") {
            addLog("SIMULASI: respons lambat dicatat tanpa menahan UI.")
        }
        addAction("Mulai / hentikan sesi") {
            running = !running
            status.text = if (running) "STATUS: SESI SIMULASI AKTIF" else "STATUS: SIAP"
            addLog(if (running) "Sesi simulasi dimulai." else "Sesi simulasi dihentikan.")
        }
        addAction("Bersihkan log") {
            logBox.removeAllViews()
            addLog("Log dibersihkan.")
        }

        val logTitle = TextView(this).apply {
            text = "LOG AKTIVITAS"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(red)
            setPadding(0, 24, 0, 8)
        }
        content.addView(logTitle, matchWrap())

        logBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(panel)
        }
        content.addView(logBox, matchWrap())

        val footer = TextView(this).apply {
            text = "Darkblade Bug v1.0 • Simulasi lokal untuk belajar"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, 20, 0, 4)
        }
        content.addView(footer, matchWrap())

        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(page)
    }

    private fun addLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val item = TextView(this).apply {
            text = "[$time] $message"
            textSize = 12f
            setTextColor(if (message.contains("terdeteksi")) red else white)
            setPadding(0, 5, 0, 5)
        }
        logBox.addView(item, 0)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
