# Darkblade Bug — Android Native

Aplikasi edukasi dengan simulasi bug lokal. Semua tombol hanya menambahkan catatan simulasi; tidak melakukan serangan, tidak mengirim trafik jaringan, dan tidak merusak aplikasi/perangkat.

## Kebutuhan
- Android Studio (versi yang mendukung Android Gradle Plugin 8.7.3)
- JDK 17
- Android SDK Platform 35

## Membuka proyek
1. Ekstrak `DarkbladeBug.zip`.
2. Buka folder `DarkbladeBug` di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Jalankan ke emulator atau perangkat Android melalui tombol Run.

## Membuat APK
1. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. Setelah proses selesai, pilih **locate** pada notifikasi build.
3. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

Untuk APK distribusi, gunakan **Build > Generate Signed Bundle / APK** dan buat signing key sendiri.

## Catatan
APK siap instal belum dikompilasi di sini. ZIP ini berisi source code proyek Android; APK perlu dibangun di Android Studio.
